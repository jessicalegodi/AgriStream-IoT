CREATE TABLE dbo.Devices (
 DeviceId NVARCHAR(100) NOT NULL PRIMARY KEY,
 OperationalStatus NVARCHAR(50) NOT NULL DEFAULT 'Idle',
 LastCommandAtUtc DATETIME2 NULL
);
IF NOT EXISTS (SELECT 1 FROM dbo.Devices WHERE DeviceId='IrrigationDevice001')
 INSERT INTO dbo.Devices(DeviceId, OperationalStatus) VALUES('IrrigationDevice001','Idle');

CREATE TABLE dbo.Users (
 UserId INT IDENTITY(1,1) PRIMARY KEY,
 Username NVARCHAR(100) NOT NULL UNIQUE,
 PasswordHash NVARCHAR(500) NOT NULL,
 Email NVARCHAR(200) NULL,
 Role NVARCHAR(30) NOT NULL
);
