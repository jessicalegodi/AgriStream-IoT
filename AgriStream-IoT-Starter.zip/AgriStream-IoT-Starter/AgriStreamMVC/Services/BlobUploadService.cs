using Azure.Storage.Blobs;
namespace AgriStreamMVC.Services;
public class BlobUploadService(IConfiguration config)
{
    public async Task<string> UploadAsync(IFormFile file)
    {
        if (file.Length == 0) throw new Exception("Choose a file.");
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!new[] { ".jpg", ".jpeg", ".png", ".webp" }.Contains(ext))
            throw new Exception("Only JPG, JPEG, PNG or WEBP images are allowed.");
        var cs = config["AzureStorage:ConnectionString"] ?? throw new Exception("Storage connection missing");
        var containerName = config["AzureStorage:BlobContainer"] ?? "drone-images";
        var container = new BlobContainerClient(cs, containerName);
        await container.CreateIfNotExistsAsync();
        var name = Guid.NewGuid() + ext;
        await using var stream = file.OpenReadStream();
        await container.GetBlobClient(name).UploadAsync(stream);
        return name;
    }
}
