using System.Net.Http.Json;
namespace AgriStreamMVC.Services;
public class FunctionClient(HttpClient http, IConfiguration config)
{
    public async Task<string> GetTelemetryAsync()
    {
        var url = config["FunctionUrls:TelemetryGet"] ?? throw new Exception("GET Function URL missing");
        using var response = await http.GetAsync(url);
        var body = await response.Content.ReadAsStringAsync();
        response.EnsureSuccessStatusCode();
        return body;
    }
    public async Task<string> SendCommandAsync(string deviceId)
    {
        var url = config["FunctionUrls:IrrigationPost"] ?? throw new Exception("POST Function URL missing");
        using var response = await http.PostAsJsonAsync(url, new {
            DeviceId = deviceId, CommandName = "StartIrrigation", Status = "Pending"
        });
        var body = await response.Content.ReadAsStringAsync();
        response.EnsureSuccessStatusCode();
        return body;
    }
}
